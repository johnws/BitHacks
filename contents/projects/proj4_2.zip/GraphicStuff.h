#ifndef GRAPHIC_STUFF_H
#define GRAPHIC_STUFF_H

#include <X11/Xlib.h>

class LineDemo;

void graphicMain(int argc, char **argv, LineDemo *lineDemo, bool imageOnlyFlag);

#endif /* GRAPHIC_STUFF_H */
