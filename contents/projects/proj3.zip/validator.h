#ifndef MM_VALIDATOR_H
#define MM_VALIDATOR_H

#include "mdriver.h"

int eval_mm_valid(malloc_impl_t *impl, trace_t *trace, int tracenum);

#endif /* MM_VALIDATOR_H */
